package mk.ukim.finki.wp.lab.data;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import mk.ukim.finki.wp.lab.model.Album;
import mk.ukim.finki.wp.lab.repository.AlbumRepository;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DataInitializr {

    private final AlbumRepository albumRepository;

    @PostConstruct
    public void initializeData() {
        for(int i=0;i<2;i++) {
            Album album = new Album("Name" + i, "Genre" + i, "Release year" + i);
            albumRepository.save(album);
        }
        Album album = new Album("White Album", "Rock", "1976");
        albumRepository.save(album);
        Album album2 = new Album("Crvena Jabuka", "Pop-Rock", "1986");
        albumRepository.save(album2);
        Album album3 = new Album("Rucni Rad", "Fusion-Jazz", "1976");
        albumRepository.save(album3);
        Album album4 = new Album("Diamonds", "Pop", "2018");
        albumRepository.save(album4);
    }
}
